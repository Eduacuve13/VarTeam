/* =========================================================
   PARTE 5 · Carrito de compras
   Agregar, quitar, cambiar cantidades y Total General
   ========================================================= */

// ---------- 7. Carrito de compras ----------
function agregarAlCarrito(id) {
  const existente = carrito.find((item) => item.id === id);
  if (existente) {
    existente.cantidad++;
  } else {
    carrito.push({ id, cantidad: 1 });
  }
  actualizarCarrito();
  mostrarAviso("success", `Agregaste "${buscarProducto(id).nombre}" al carrito.`);
}

function cambiarCantidad(id, delta) {
  const item = carrito.find((i) => i.id === id);
  if (!item) return;
  item.cantidad += delta;
  if (item.cantidad <= 0) quitarDelCarrito(id);
  else actualizarCarrito();
}

function quitarDelCarrito(id) {
  carrito = carrito.filter((i) => i.id !== id);
  actualizarCarrito();
}

function actualizarCarrito() {
  const cuerpo = document.querySelector("#cuerpoCarrito");
  cuerpo.innerHTML = "";
  const fragmento = document.createDocumentFragment();

  let total = 0;
  let ahorro = 0;
  let unidades = 0;

  carrito.forEach((item) => {
    const p = buscarProducto(item.id);
    const subtotal = precioFinal(p) * item.cantidad;
    total += subtotal;
    ahorro += (p.precio - precioFinal(p)) * item.cantidad;
    unidades += item.cantidad;

    const fila = document.createElement("tr");
    fila.innerHTML = `
      <td data-label="Producto"></td>
      <td data-label="Precio">${formato(precioFinal(p))}</td>
      <td data-label="Cantidad">
        <span class="cantidad">
          <button type="button" class="btn btn-sm btn-outline-primary" data-accion="menos" data-id="${p.id}" aria-label="Quitar una unidad">−</button>
          <output>${item.cantidad}</output>
          <button type="button" class="btn btn-sm btn-outline-primary" data-accion="mas" data-id="${p.id}" aria-label="Agregar una unidad">+</button>
        </span>
      </td>
      <td data-label="Subtotal">${formato(subtotal)}</td>
      <td class="celda-quitar"><button type="button" class="btn btn-sm btn-outline-primary" data-accion="quitar" data-id="${p.id}">Eliminar</button></td>`;
    fila.firstElementChild.textContent = p.nombre;
    fragmento.appendChild(fila);
  });

  cuerpo.appendChild(fragmento);

  const hayItems = carrito.length > 0;
  document.querySelector("#carritoVacio").classList.toggle("d-none", hayItems);
  document.querySelector("#tablaCarrito").classList.toggle("d-none", !hayItems);
  document.querySelector("#resumenCarrito").classList.toggle("d-none", !hayItems);
  document.querySelector("#ahorroCarrito").textContent = formato(ahorro);
  document.querySelector("#totalGeneral").textContent = formato(total);
  document.querySelector("#contador").textContent = unidades;
}

function finalizarCompra() {
  if (carrito.length === 0) {
    mostrarAviso("warning", "Tu carrito está vacío.");
  } else if (usuario === null) {
    mostrarAviso("warning", "Inicia sesión para finalizar tu compra.");
  } else {
    carrito = [];
    actualizarCarrito();
    document.querySelector("#modalCarrito .btn-close").click();
    mostrarAviso("success", `Gracias, ${usuario.nombre}. Registramos tu compra (demostración).`);
  }
}
