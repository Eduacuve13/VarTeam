/* =========================================================
   PARTE 2 · Estado y patrones
   Variables que cambian (let) y expresiones regulares para validar
   ========================================================= */

// ---------- Estado de la aplicación (let: cambia con el tiempo) ----------
let carrito = [];              // [{ id, cantidad }]
let usuario = null;            // { nombre, correo } o null
let categoriaActiva = "Todos";
let textoBusqueda = "";
let numeroReclamo = 1;

// ---------- Expresiones regulares ----------
const reCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const reCelular = /^9\d{8}$/;
const reDni = /^\d{8}$/;
const reCarne = /^\d{9,12}$/;
