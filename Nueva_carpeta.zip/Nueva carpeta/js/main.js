/* =========================================================
   PARTE 9 · Arranque
   Conecta todo cuando el HTML está listo (DOMContentLoaded)
   ========================================================= */

// ---------- Inicio: se ejecuta cuando el HTML está listo ----------
document.addEventListener("DOMContentLoaded", () => {
  // Imágenes de la portada
  document.querySelectorAll("[data-hero]").forEach((img) => {
    const p = buscarProducto(Number(img.dataset.hero));
    img.src = imagen(p);
    img.alt = altDe(p);
  });

  // Lista de productos para el libro de reclamaciones
  const select = document.querySelector("#rcProducto");
  productos.forEach((p) => {
    const opcion = document.createElement("option");
    opcion.value = p.id;
    opcion.textContent = p.nombre;
    select.appendChild(opcion);
  });

  mostrarCatalogo();
  mostrarVendidos();
  mostrarOfertas();
  mostrarExhibicion();
  actualizarCarrito();
  actualizarSesion();

  // Búsqueda
  document.querySelector("#buscador").addEventListener("keyup", (e) => {
    textoBusqueda = e.target.value;
    mostrarCatalogo();
  });

  // Filtros por categoría
  document.querySelector("#filtros").addEventListener("click", (e) => {
    const boton = e.target.closest("[data-categoria]");
    if (!boton) return;
    seleccionarCategoria(boton.dataset.categoria);
  });

  // Botones del carrusel que llevan al catálogo con una categoría ya elegida
  document.querySelectorAll("[data-ir-categoria]").forEach((enlace) => {
    enlace.addEventListener("click", () => seleccionarCategoria(enlace.dataset.irCategoria));
  });

  // Carrusel: si la persona prefiere menos movimiento, no avanza solo
  const carrusel = document.querySelector("#carruselInicio");
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    bootstrap.Carousel.getOrCreateInstance(carrusel).pause();
  }

  // Delegación de eventos: los botones creados dinámicamente también responden
  document.addEventListener("click", (e) => {
    const el = e.target.closest("[data-accion]");
    if (!el) return;
    const id = Number(el.dataset.id);

    switch (el.dataset.accion) {
      case "agregar": agregarAlCarrito(id); break;
      case "detalle": mostrarDetalle(id); break;
      case "mas": cambiarCantidad(id, 1); break;
      case "menos": cambiarCantidad(id, -1); break;
      case "quitar": quitarDelCarrito(id); break;
      case "vaciar": carrito = []; actualizarCarrito(); break;
      case "finalizar": finalizarCompra(); break;
      case "salir": cerrarSesion(); break;
    }
  });

  // Navegación entre "páginas": cada enlace del menú carga solo su funcionalidad
  window.addEventListener("hashchange", () => mostrarVista(true));
  mostrarVista(false);

  // Formularios
  document.querySelector("#formLogin").addEventListener("submit", iniciarSesion);
  document.querySelector("#formSoporte").addEventListener("submit", enviarSoporte);
  document.querySelector("#formReclamo").addEventListener("submit", registrarReclamo);
});

// ---------- Vistas: la página principal y cada funcionalidad se muestran por separado ----------
// Las secciones con data-vista="inicio" forman la página principal (carrusel, exhibición, ofertas).
// Las demás (catálogo, más vendidos, soporte, reclamos) se cargan solas al elegirlas en el menú.
function mostrarVista(desplazar) {
  const id = decodeURIComponent(location.hash.slice(1));
  const destino = id ? document.getElementById(id) : null;
  const vista = destino && destino.dataset.vista ? destino.dataset.vista : "inicio";

  document.querySelectorAll("[data-vista]").forEach((s) => {
    s.hidden = s.dataset.vista !== vista;
  });

  // Marca el enlace activo del menú
  const activo = vista === "inicio" && id === "ofertas" ? "ofertas" : vista;
  document.querySelectorAll(".navbar-nav .nav-link").forEach((a) => {
    const esActivo = a.getAttribute("href") === `#${activo}`;
    a.classList.toggle("active", esActivo);
    if (esActivo) a.setAttribute("aria-current", "page");
    else a.removeAttribute("aria-current");
  });

  // Cierra el menú desplegable en móvil
  const menu = document.querySelector("#menu");
  if (menu.classList.contains("show")) bootstrap.Collapse.getOrCreateInstance(menu).hide();

  if (!desplazar) return;
  if (vista === "inicio" && destino && id !== "inicio") destino.scrollIntoView();
  else window.scrollTo(0, 0);
}
