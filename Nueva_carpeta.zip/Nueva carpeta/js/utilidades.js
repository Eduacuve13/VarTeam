/* =========================================================
   PARTE 3 · Utilidades
   Formato de precios, estrellas, imágenes SVG, avisos y validación de campos
   ========================================================= */

// ---------- Funciones de apoyo ----------
const formato = (n) => `${MONEDA} ${n.toFixed(2)}`;

const precioFinal = (p) => Math.round(p.precio * (100 - p.descuento)) / 100;

const promedio = (p) => p.resenas.reduce((suma, r) => suma + r.puntos, 0) / p.resenas.length;

const estrellas = (n) => {
  const llenas = Math.round(n);
  return "★".repeat(llenas) + "☆".repeat(5 - llenas);
};

// Quita tildes y pasa a minúsculas para buscar sin importar acentos
const normalizar = (texto) =>
  texto.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim();

const buscarProducto = (id) => productos.find((p) => p.id === id);

// Imágenes: se dibujan como SVG para no depender de archivos externos
function imagen(p) {
  const fondos = { "Maquillaje": "#fbe4ec", "Perfumes": "#ece6f6", "Cuidado facial": "#e2f1ee" };
  const c = p.color;
  const formas = {
    labial: `<rect x="170" y="150" width="60" height="100" rx="6" fill="#2a1730"/>
             <rect x="176" y="90" width="48" height="66" rx="6" fill="${c}"/>
             <path d="M176 96 L224 78 L224 100 Z" fill="${c}"/>`,
    perfume: `<rect x="150" y="120" width="100" height="120" rx="14" fill="${c}"/>
              <rect x="185" y="90" width="30" height="34" fill="#2a1730"/>
              <rect x="170" y="66" width="60" height="28" rx="6" fill="#2a1730"/>
              <rect x="164" y="140" width="14" height="80" rx="7" fill="#ffffff" opacity="0.35"/>`,
    crema: `<rect x="130" y="160" width="140" height="80" rx="14" fill="${c}"/>
            <rect x="124" y="128" width="152" height="40" rx="10" fill="#2a1730"/>`,
    serum: `<rect x="160" y="130" width="80" height="112" rx="14" fill="${c}"/>
            <rect x="188" y="92" width="24" height="42" fill="#2a1730"/>
            <ellipse cx="200" cy="80" rx="24" ry="22" fill="#2a1730"/>`,
    frasco: `<rect x="155" y="110" width="90" height="130" rx="14" fill="${c}"/>
             <rect x="180" y="82" width="40" height="32" rx="4" fill="#2a1730"/>
             <rect x="172" y="150" width="56" height="50" rx="6" fill="#ffffff" opacity="0.5"/>`,
    paleta: `<rect x="90" y="100" width="220" height="130" rx="16" fill="#2a1730"/>
             <circle cx="140" cy="145" r="22" fill="${c}"/><circle cx="200" cy="145" r="22" fill="#e8a5b8"/><circle cx="260" cy="145" r="22" fill="#f2c9a0"/>
             <circle cx="140" cy="200" r="22" fill="#c98aa6"/><circle cx="200" cy="200" r="22" fill="#a66a8a"/><circle cx="260" cy="200" r="22" fill="#e6b7c8"/>`
  };
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300">
    <rect width="400" height="300" fill="${fondos[p.categoria]}"/>
    <ellipse cx="200" cy="248" rx="110" ry="12" fill="#2a1730" opacity="0.12"/>
    ${formas[p.tipo]}
  </svg>`;
  return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
}

const altDe = (p) => `${p.nombre}, ${p.categoria.toLowerCase()}`;


// ---------- Avisos (alerts de Bootstrap creados con createElement) ----------
function mostrarAviso(tipo, texto) {
  const aviso = document.createElement("div");
  aviso.className = `alert alert-${tipo}`;
  aviso.setAttribute("role", "alert");
  aviso.textContent = texto;               // textContent: no interpreta HTML (evita XSS)
  document.querySelector("#avisos").appendChild(aviso);
  setTimeout(() => aviso.remove(), 3800);  // limpieza: se elimina del DOM
}

// ---------- Validación de formularios ----------
// Marca el campo y escribe el mensaje. No depende solo del color: siempre hay texto.
function marcar(campo, valido, mensaje = "") {
  campo.classList.toggle("is-invalid", !valido);
  campo.classList.toggle("is-valid", valido);
  const aviso = campo.parentElement.querySelector(".invalid-feedback");
  if (aviso) aviso.textContent = mensaje;
  return valido;
}

function limpiarFormulario(form) {
  form.reset();
  form.querySelectorAll(".is-valid, .is-invalid").forEach((c) => c.classList.remove("is-valid", "is-invalid"));
}

const todosValidos = (resultados) => resultados.every((r) => r === true);
