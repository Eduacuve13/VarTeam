/* =========================================================
   PARTE 8 · Libro de reclamaciones
   Formulario de reclamos y quejas
   ========================================================= */

// ---------- 10. Libro de reclamaciones ----------
function registrarReclamo(evento) {
  evento.preventDefault();
  const f = (id) => document.querySelector(id);
  const nombre = f("#rcNombre"), tipoDoc = f("#rcTipoDoc"), numDoc = f("#rcNumDoc");
  const domicilio = f("#rcDomicilio"), telefono = f("#rcTelefono"), correo = f("#rcCorreo");
  const producto = f("#rcProducto"), monto = f("#rcMonto");
  const detalle = f("#rcDetalle"), pedido = f("#rcPedido"), acepta = f("#rcAcepta");

  const patronDoc = tipoDoc.value === "DNI" ? reDni : reCarne;
  const msgDoc = tipoDoc.value === "DNI" ? "El DNI tiene 8 números." : "El carné tiene entre 9 y 12 números.";

  const ok = todosValidos([
    marcar(nombre, nombre.value.trim().length >= 3, "Escribe tu nombre completo."),
    marcar(numDoc, patronDoc.test(numDoc.value.trim()), msgDoc),
    marcar(domicilio, domicilio.value.trim().length >= 5, "Escribe tu domicilio."),
    marcar(telefono, reCelular.test(telefono.value.trim()), "El celular tiene 9 números y empieza con 9."),
    marcar(correo, reCorreo.test(correo.value.trim()), "Escribe un correo válido."),
    marcar(producto, producto.value !== "", "Elige el producto del reclamo."),
    marcar(monto, Number(monto.value) > 0, "Escribe un monto mayor a 0."),
    marcar(detalle, detalle.value.trim().length >= 20, "Describe lo ocurrido (mínimo 20 caracteres)."),
    marcar(pedido, pedido.value.trim().length >= 5, "Indica qué solución esperas."),
    marcar(acepta, acepta.checked, "Debes aceptar el uso de tus datos para registrar el reclamo.")
  ]);

  if (!ok) {
    mostrarAviso("danger", "No se registró: completa los campos marcados.");
    return;
  }

  const tipo = document.querySelector('input[name="rcTipo"]:checked').value;
  const codigo = `LR-${String(numeroReclamo).padStart(4, "0")}`;
  numeroReclamo++;

  const resultado = f("#resultadoReclamo");
  const caja = document.createElement("div");
  caja.className = "alert alert-success";
  // textContent: lo que escribe el usuario nunca se interpreta como HTML
  caja.textContent = `Registramos tu ${tipo} con el código ${codigo}. Producto: ${producto.options[producto.selectedIndex].text}. Te responderemos a ${correo.value.trim()}.`;
  resultado.innerHTML = "";
  resultado.appendChild(caja);

  limpiarFormulario(evento.target);
  mostrarAviso("success", `Reclamo ${codigo} registrado.`);
  caja.scrollIntoView({ block: "center" });
}
