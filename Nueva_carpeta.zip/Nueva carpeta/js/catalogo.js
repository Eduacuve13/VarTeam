/* =========================================================
   PARTE 4 · Catálogo
   Tarjetas, búsqueda, filtros, más vendidos, ofertas y detalle con reseñas
   ========================================================= */

// ---------- Plantilla de tarjeta (template string) ----------
function crearTarjeta(p) {
  const prom = promedio(p);
  const etiqueta = p.descuento > 0 ? `<span class="etiqueta-oferta">-${p.descuento}%</span>` : "";
  const precio = p.descuento > 0
    ? `${formato(precioFinal(p))} <del>${formato(p.precio)}</del>`
    : formato(p.precio);

  return `
    <div class="col-12 col-md-6 col-lg-4">
      <article class="card producto h-100">
        ${etiqueta}
        <img src="${imagen(p)}" class="card-img-top" alt="${altDe(p)}" width="400" height="300" loading="lazy">
        <div class="card-body d-flex flex-column">
          <p class="categoria text-muted">${p.categoria}</p>
          <h3 class="card-title h5">${p.nombre}</h3>
          <p class="estrellas" aria-label="Calificación ${prom.toFixed(1)} de 5">
            ${estrellas(prom)} <span>${prom.toFixed(1)} (${p.resenas.length} reseñas)</span>
          </p>
          <div class="precio-fila">
            <p class="precio">${precio}</p>
            <button type="button" class="btn btn-primary" data-accion="agregar" data-id="${p.id}">Agregar</button>
          </div>
          <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                  data-bs-target="#modalProducto" data-accion="detalle" data-id="${p.id}">Ver detalles</button>
        </div>
      </article>
    </div>`;
}

// ---------- 1 y 2. Catálogo, categorías y búsqueda ----------
function mostrarCatalogo() {
  const lista = document.querySelector("#listaProductos");
  const texto = normalizar(textoBusqueda);

  const filtrados = productos.filter((p) => {
    const coincideCategoria = categoriaActiva === "Todos" || p.categoria === categoriaActiva;
    const coincideTexto = normalizar(`${p.nombre} ${p.categoria}`).includes(texto);
    return coincideCategoria && coincideTexto;
  });

  lista.innerHTML = filtrados.map(crearTarjeta).join("");
  document.querySelector("#sinResultados").classList.toggle("d-none", filtrados.length > 0);
  document.querySelector("#conteo").textContent =
    filtrados.length === 1 ? "1 producto" : `${filtrados.length} productos`;
}

// Cambia la categoría activa y actualiza los botones del filtro
function seleccionarCategoria(nombre) {
  categoriaActiva = nombre;
  document.querySelectorAll("#filtros button").forEach((b) => {
    const activo = b.dataset.categoria === nombre;
    b.classList.toggle("btn-primary", activo);
    b.classList.toggle("btn-outline-primary", !activo);
    b.setAttribute("aria-pressed", activo);
  });
  mostrarCatalogo();
}

// ---------- 3. Más vendidos ----------
function mostrarVendidos() {
  const top = [...productos].sort((a, b) => b.ventas - a.ventas).slice(0, 4);
  const lista = document.querySelector("#listaVendidos");

  lista.innerHTML = top.map((p, i) => `
    <li class="top-item">
      <span class="puesto" aria-label="Puesto ${i + 1}">${i + 1}</span>
      <img src="${imagen(p)}" alt="${altDe(p)}" width="400" height="300" loading="lazy">
      <div class="top-info">
        <h3>${p.nombre}</h3>
        <p class="text-muted small mb-1">${p.ventas} vendidos</p>
        <p class="precio mb-2">${formato(precioFinal(p))}</p>
        <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal"
                data-bs-target="#modalProducto" data-accion="detalle" data-id="${p.id}">Ver detalles</button>
      </div>
    </li>`).join("");
}

// ---------- 6. Promociones ----------
function mostrarOfertas() {
  const enOferta = productos.filter((p) => p.descuento > 0);
  document.querySelector("#listaOfertas").innerHTML = enOferta.map(crearTarjeta).join("");
}

// ---------- Productos en exhibición (página principal) ----------
function mostrarExhibicion() {
  const exhibidos = productos.filter((p) => p.descuento === 0).slice(0, 6);
  document.querySelector("#listaExhibicion").innerHTML = exhibidos.map(crearTarjeta).join("");
}

// ---------- 4 y 5. Detalle del producto y reseñas ----------
function mostrarDetalle(id) {
  const p = buscarProducto(id);
  const prom = promedio(p);

  document.querySelector("#detalleNombre").textContent = p.nombre;
  const img = document.querySelector("#detalleImg");
  img.src = imagen(p);
  img.alt = altDe(p);
  document.querySelector("#detalleCategoria").textContent = p.categoria;
  document.querySelector("#detallePrecio").innerHTML = p.descuento > 0
    ? `${formato(precioFinal(p))} <del>${formato(p.precio)}</del> (-${p.descuento}%)`
    : formato(p.precio);
  document.querySelector("#detalleEstrellas").innerHTML =
    `${estrellas(prom)} <span>${prom.toFixed(1)} de 5</span>`;
  document.querySelector("#detalleDescripcion").textContent = p.descripcion;
  document.querySelector("#detalleAgregar").dataset.id = p.id;

  // Características: createElement + DocumentFragment
  const ul = document.querySelector("#detalleCaracteristicas");
  ul.innerHTML = "";
  const fragmento = document.createDocumentFragment();
  p.caracteristicas.forEach((texto) => {
    const li = document.createElement("li");
    li.textContent = texto;
    fragmento.appendChild(li);
  });
  ul.appendChild(fragmento);

  // Reseñas
  const lista = document.querySelector("#detalleResenas");
  lista.innerHTML = "";
  const frag2 = document.createDocumentFragment();
  p.resenas.forEach((r) => {
    const li = document.createElement("li");
    const cabecera = document.createElement("div");
    const autor = document.createElement("span");
    autor.className = "autor";
    autor.textContent = r.autor;
    const pts = document.createElement("span");
    pts.className = "estrellas ms-2";
    pts.textContent = `${estrellas(r.puntos)} ${r.puntos}/5`;
    cabecera.append(autor, pts);
    const texto = document.createElement("p");
    texto.className = "mb-0";
    texto.textContent = r.texto;
    li.append(cabecera, texto);
    frag2.appendChild(li);
  });
  lista.appendChild(frag2);
}
