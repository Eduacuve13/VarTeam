/* =========================================================
   PARTE 7 · Soporte al cliente
   Formulario de contacto
   ========================================================= */

// ---------- 9. Soporte al cliente ----------
function enviarSoporte(evento) {
  evento.preventDefault();
  const nombre = document.querySelector("#spNombre");
  const correo = document.querySelector("#spCorreo");
  const asunto = document.querySelector("#spAsunto");
  const mensaje = document.querySelector("#spMensaje");

  const ok = todosValidos([
    marcar(nombre, nombre.value.trim().length >= 3, "Escribe tu nombre (mínimo 3 letras)."),
    marcar(correo, reCorreo.test(correo.value.trim()), "Escribe un correo válido para poder responderte."),
    marcar(asunto, asunto.value !== "", "Elige el motivo de tu consulta."),
    marcar(mensaje, mensaje.value.trim().length >= 10, "Cuéntanos tu consulta (mínimo 10 caracteres).")
  ]);

  if (!ok) {
    mostrarAviso("danger", "No se envió: faltan datos o hay errores en el formulario.");
    return;
  }
  mostrarAviso("success", `Gracias, ${nombre.value.trim()}. Recibimos tu consulta y te responderemos a ${correo.value.trim()}.`);
  limpiarFormulario(evento.target);
}
