/* =========================================================
   PARTE 1 · Datos
   Arreglo de productos (id, precio, descuento, ventas, reseñas...)
   ========================================================= */

const MONEDA = "S/";

const productos = [
  {
    id: 1, nombre: "Labial Mate Peonía", categoria: "Maquillaje", tipo: "labial", color: "#b3154f",
    precio: 39.9, descuento: 0, ventas: 412,
    descripcion: "Labial de acabado mate en un tono rosa intenso, pensado para el uso diario.",
    caracteristicas: ["Acabado mate", "Tono rosa peonía", "Barra de 3.5 g"],
    resenas: [
      { autor: "Camila R.", puntos: 5, texto: "El color es tal cual la foto y no se corre." },
      { autor: "Lucía P.", puntos: 4, texto: "Dura varias horas, un poco seco en los labios." }
    ]
  },
  {
    id: 2, nombre: "Base Líquida Piel Natural", categoria: "Maquillaje", tipo: "frasco", color: "#d9a27e",
    precio: 69.9, descuento: 15, ventas: 380,
    descripcion: "Base líquida de cobertura media que unifica el tono sin sentirse pesada.",
    caracteristicas: ["Cobertura media", "Frasco de 30 ml", "Acabado natural"],
    resenas: [
      { autor: "Andrea M.", puntos: 5, texto: "Se difumina fácil y se ve natural." },
      { autor: "Rosa T.", puntos: 4, texto: "Buen precio con el descuento." }
    ]
  },
  {
    id: 3, nombre: "Paleta de Sombras Atardecer", categoria: "Maquillaje", tipo: "paleta", color: "#8e4a6b",
    precio: 89.9, descuento: 20, ventas: 295,
    descripcion: "Paleta de seis sombras en tonos cálidos, mates y brillantes.",
    caracteristicas: ["6 colores", "Mates y satinados", "Espejo incluido"],
    resenas: [
      { autor: "Valeria S.", puntos: 5, texto: "Los colores son muy pigmentados." },
      { autor: "Karen L.", puntos: 4, texto: "Linda paleta, el estuche podría ser más firme." }
    ]
  },
  {
    id: 4, nombre: "Máscara de Pestañas Volumen", categoria: "Maquillaje", tipo: "labial", color: "#2a1730",
    precio: 34.9, descuento: 0, ventas: 330,
    descripcion: "Máscara negra que separa y levanta las pestañas con un cepillo curvo.",
    caracteristicas: ["Color negro", "Cepillo curvo", "Tubo de 9 ml"],
    resenas: [
      { autor: "Daniela C.", puntos: 4, texto: "Da volumen sin hacer grumos." },
      { autor: "Mariana V.", puntos: 4, texto: "Cumple, se quita bien con desmaquillante." }
    ]
  },
  {
    id: 5, nombre: "Rubor en Crema Durazno", categoria: "Maquillaje", tipo: "crema", color: "#f29e8e",
    precio: 44.9, descuento: 10, ventas: 210,
    descripcion: "Rubor cremoso que se aplica con los dedos y deja un color fresco en las mejillas.",
    caracteristicas: ["Textura cremosa", "Tono durazno", "Tarro de 8 g"],
    resenas: [
      { autor: "Patricia H.", puntos: 5, texto: "Se mezcla muy bien con la base." },
      { autor: "Sofía Q.", puntos: 3, texto: "Bonito color, pero rinde poco." }
    ]
  },
  {
    id: 6, nombre: "Eau de Parfum Noche Azul", categoria: "Perfumes", tipo: "perfume", color: "#3f51b5",
    precio: 189, descuento: 0, ventas: 260,
    descripcion: "Fragancia amaderada con notas de lavanda y vainilla, para la noche.",
    caracteristicas: ["Eau de parfum", "Frasco de 50 ml", "Notas amaderadas"],
    resenas: [
      { autor: "Jorge A.", puntos: 5, texto: "Se queda en la ropa todo el día." },
      { autor: "Elena G.", puntos: 4, texto: "Elegante, algo intenso para el verano." }
    ]
  },
  {
    id: 7, nombre: "Eau de Toilette Cítrico Fresco", categoria: "Perfumes", tipo: "perfume", color: "#d9a400",
    precio: 129, descuento: 25, ventas: 305,
    descripcion: "Fragancia ligera con limón, mandarina y té verde, ideal para el día.",
    caracteristicas: ["Eau de toilette", "Frasco de 100 ml", "Notas cítricas"],
    resenas: [
      { autor: "Miguel F.", puntos: 5, texto: "Fresco y no cansa." },
      { autor: "Carla N.", puntos: 4, texto: "Dura menos que un parfum, pero huele rico." }
    ]
  },
  {
    id: 8, nombre: "Perfume Floral Jazmín", categoria: "Perfumes", tipo: "perfume", color: "#9c5bc9",
    precio: 159, descuento: 0, ventas: 188,
    descripcion: "Perfume floral con jazmín y flor de azahar, suave y dulce.",
    caracteristicas: ["Eau de parfum", "Frasco de 50 ml", "Notas florales"],
    resenas: [
      { autor: "Gabriela D.", puntos: 5, texto: "Muy femenino, me lo piden siempre." },
      { autor: "Isabel O.", puntos: 4, texto: "Aroma agradable y delicado." }
    ]
  },
  {
    id: 9, nombre: "Sérum de Vitamina C", categoria: "Cuidado facial", tipo: "serum", color: "#e08a00",
    precio: 99.9, descuento: 30, ventas: 450,
    descripcion: "Sérum ligero con vitamina C para usar en la mañana antes de la crema.",
    caracteristicas: ["Frasco con gotero de 30 ml", "Textura ligera", "Uso diario"],
    resenas: [
      { autor: "Natalia B.", puntos: 5, texto: "Se absorbe rápido y no deja pegajosa la piel." },
      { autor: "Paola E.", puntos: 4, texto: "Lo uso hace un mes, me gusta su textura." }
    ]
  },
  {
    id: 10, nombre: "Crema Hidratante con Ácido Hialurónico", categoria: "Cuidado facial", tipo: "crema", color: "#5ba8a0",
    precio: 79.9, descuento: 0, ventas: 398,
    descripcion: "Crema de uso diario que deja la piel suave e hidratada.",
    caracteristicas: ["Con ácido hialurónico", "Tarro de 50 ml", "Para todo tipo de piel"],
    resenas: [
      { autor: "Fiorella J.", puntos: 5, texto: "Hidrata sin dejar brillo." },
      { autor: "Diana K.", puntos: 5, texto: "Mi piel se siente suave todo el día." }
    ]
  },
  {
    id: 11, nombre: "Limpiador Facial en Gel", categoria: "Cuidado facial", tipo: "frasco", color: "#7fb7be",
    precio: 49.9, descuento: 15, ventas: 276,
    descripcion: "Gel limpiador que retira el maquillaje y la grasa sin resecar.",
    caracteristicas: ["Gel transparente", "Frasco de 150 ml", "Uso mañana y noche"],
    resenas: [
      { autor: "Alejandra Z.", puntos: 4, texto: "Hace buena espuma y huele fresco." },
      { autor: "Rocío U.", puntos: 4, texto: "Limpia bien, lo volvería a comprar." }
    ]
  },
  {
    id: 12, nombre: "Protector Solar FPS 50", categoria: "Cuidado facial", tipo: "frasco", color: "#f2c14e",
    precio: 59.9, descuento: 0, ventas: 340,
    descripcion: "Protector solar facial de textura fluida, para usar todos los días.",
    caracteristicas: ["FPS 50", "Textura fluida", "Frasco de 50 ml"],
    resenas: [
      { autor: "Teresa W.", puntos: 5, texto: "No deja capa blanca." },
      { autor: "Renata Y.", puntos: 4, texto: "Se siente liviano bajo el maquillaje." }
    ]
  }
];
