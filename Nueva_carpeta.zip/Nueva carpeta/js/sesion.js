/* =========================================================
   PARTE 6 · Sesión de usuario
   Iniciar y cerrar sesión
   ========================================================= */

// ---------- 8. Inicio y cierre de sesión ----------
function actualizarSesion() {
  const boton = document.querySelector("#btnSesion");
  const saludo = document.querySelector("#saludo");

  if (usuario) {
    saludo.textContent = `Hola, ${usuario.nombre}`;
    boton.textContent = "Cerrar sesión";
    boton.removeAttribute("data-bs-toggle");
    boton.removeAttribute("data-bs-target");
    boton.dataset.accion = "salir";
  } else {
    saludo.textContent = "";
    boton.textContent = "Iniciar sesión";
    boton.setAttribute("data-bs-toggle", "modal");
    boton.setAttribute("data-bs-target", "#modalLogin");
    delete boton.dataset.accion;
  }
}

function iniciarSesion(evento) {
  evento.preventDefault();
  const correo = document.querySelector("#lgCorreo");
  const clave = document.querySelector("#lgClave");

  const ok = todosValidos([
    marcar(correo, reCorreo.test(correo.value.trim()), "Escribe un correo válido, por ejemplo nombre@correo.com."),
    marcar(clave, clave.value.length >= 6, "La contraseña debe tener al menos 6 caracteres.")
  ]);

  if (!ok) {
    mostrarAviso("danger", "Revisa los campos marcados.");
    return;
  }

  const parte = correo.value.trim().split("@")[0];
  usuario = { nombre: parte.charAt(0).toUpperCase() + parte.slice(1), correo: correo.value.trim() };
  limpiarFormulario(evento.target);
  document.querySelector("#modalLogin .btn-close").click();
  actualizarSesion();
  mostrarAviso("success", `Sesión iniciada. Bienvenida, ${usuario.nombre}.`);
}

function cerrarSesion() {
  usuario = null;
  actualizarSesion();
  mostrarAviso("info", "Cerraste sesión.");
}
